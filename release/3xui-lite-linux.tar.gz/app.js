const zh = {
  run: '运行中', stop: '已暂停', pause: '暂停', enable: '启用', del: '删除', copyLink: '复制链接', copyJson: '复制 JSON', copied: '已复制',
  emptyRelay: '没有符合条件的中转规则。', emptyInbound: '暂无入站节点。', emptyUser: '暂无用户。',
  confirmRelay: '确定删除这条中转规则吗？', confirmInbound: '确定删除这个节点吗？', confirmUser: '确定删除这个用户吗？',
  listen: '监听端口', server: '服务器', security: '安全层', template: '模板', remark: '备注', noRemark: '未填写', link: '节点链接', apiFailed: '读取数据失败，请确认服务已启动并重新登录。'
};
const pageNames = { overview: '概览', inbounds: '入站管理', relays: '中转面板', users: '用户管理', traffic: '流量统计', system: '系统设置' };
pageNames.agents = 'Agent 管理';
const inboundTemplates = {
  'VLESS + Reality': { key: 'reality', name: 'VLESS Reality 模板', desc: 'TCP + REALITY，自动生成 UUID、公私钥、shortId 和 vless:// 链接。', defaults: { port: '443', sni: 'www.microsoft.com', dest: 'www.microsoft.com:443', fingerprint: 'chrome', flow: 'xtls-rprx-vision' } },
  VLESS: { key: 'vless', name: '纯 VLESS TCP 模板', desc: 'TCP + 无传输安全层，自动生成 UUID 和 vless:// 链接。适合置于反向代理或内网转发之后。', defaults: { port: '8080' } },
  'VLESS + TLS': { key: 'tls', name: 'VLESS TLS 模板', desc: 'TCP + TLS，自动生成 UUID；需配置有效 TLS 证书后再对外使用。', defaults: { port: '443', sni: '' } },
  'VLESS + WebSocket': { key: 'ws', name: 'VLESS WebSocket + TLS 模板', desc: 'WS + TLS，适合经由 Nginx、CDN 或反向代理接入。', defaults: { port: '443', sni: '', path: '/vless', host: '' } },
  'VLESS + gRPC': { key: 'grpc', name: 'VLESS gRPC + TLS 模板', desc: 'gRPC + TLS，自动使用 serviceName；适合 HTTP/2 反向代理场景。', defaults: { port: '443', sni: '', serviceName: 'vless-grpc' } },  'Trojan + TLS': { key: 'tls', name: 'Trojan TLS 模板', desc: 'TCP + TLS，自动生成 Trojan 密码和 trojan:// 链接。保存 TLS 证书后可自动写入新节点。', defaults: { port: '443', sni: '', fingerprint: 'chrome' } },
  Shadowsocks: { key: 'ss', name: 'Shadowsocks 2022 模板', desc: 'TCP/UDP SS2022，自动生成服务端 PSK、用户 PSK 和 ss:// 链接。', defaults: { port: '8388', method: '2022-blake3-aes-128-gcm' } }
};
let relays = [], inbounds = [], users = [], agents = [], filter = 'all', systemInfo = null, traffic = null, editingInboundId = null;
const agentCardCollapsed = new Set((() => { try { const value = JSON.parse(localStorage.getItem('3xui-agent-collapsed') || '[]'); return Array.isArray(value) ? value : []; } catch { return []; } })());
const $ = selector => document.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g, match => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[match]));

async function api(url, options = {}) {
  const res = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
  const payload = res.status === 204 ? null : await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401) showLogin();
    throw new Error(payload.error || '请求失败');
  }
  return payload;
}
function showLogin(note = '') { $('#loginGate').classList.remove('hidden'); if (note) $('#loginNote').textContent = note; }
function hideLogin() { $('#loginGate').classList.add('hidden'); }
function formatBytes(value) {
  const bytes = Math.max(0, Number(value || 0));
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}
function relayState(relay) { return relay.runtimeStatus || relay.status || 'stopped'; }
function renderRelays() {
  const search = $('#search').value.toLowerCase();
  const list = relays.filter(relay => { const state = relayState(relay); return (filter === 'all' || state === filter) && Object.values(relay).join(' ').toLowerCase().includes(search); });
  $('#cards').innerHTML = list.length ? list.map(relay => {
    const state = relayState(relay), live = state === 'running'; const listen = relay.listenPort ? `${relay.bindAddress || '0.0.0.0'}:${relay.listenPort}` : '旧版档案'; const target = relay.targetHost ? `${relay.targetHost}:${relay.targetPort}` : (relay.exit || '需补充目标地址');
    const stateText = state === 'running' ? zh.run : state === 'error' ? '异常' : state === 'legacy' ? '需迁移' : state === 'starting' ? '下发中' : state === 'offline' ? 'Agent 离线' : state === 'disabled' ? 'Agent 停用' : zh.stop;
    const detail = ['error', 'legacy', 'offline', 'disabled'].includes(state) ? (relay.lastError || '规则尚未运行') : `连接 ${Number(relay.connections || 0)} · ↑${formatBytes(relay.bytesIn)} ↓${formatBytes(relay.bytesOut)}`;
    const executor = relay.agentId ? `Agent · ${relay.agentName || relay.agentId}` : '本机面板'; const controls = state === 'legacy' ? `<button class="btn danger" onclick="deleteRelay(${relay.id})">${zh.del}</button>` : `<button class="btn" onclick="toggleRelay(${relay.id})">${live || state === 'starting' ? zh.pause : zh.enable}</button> <button class="btn danger" onclick="deleteRelay(${relay.id})">${zh.del}</button>`;
    return `<article class="relay-card"><div class="name"><b>⇄</b><strong>${esc(relay.name)}</strong><small>${esc(String(relay.transport || 'tcp').toUpperCase())} · ${esc(executor)}</small></div><div class="route"><b>${esc(listen)}</b><i></i><span>${esc(target)}</span><small>${esc(relay.exit || '目标服务')}</small></div><div class="status ${esc(state)}">${stateText}<br><small title="${esc(relay.lastError || '')}">${esc(detail)}</small></div><div>${controls}</div></article>`;
  }).join('') : `<article>${zh.emptyRelay}</article>`;
  $('#activeCount').textContent = relays.filter(relay => relayState(relay) === 'running').length;
  $('#health').innerHTML = relays.map(relay => { const state = relayState(relay), listen = relay.listenPort ? `${relay.bindAddress || '0.0.0.0'}:${relay.listenPort}` : '需迁移', target = relay.targetHost ? `${relay.targetHost}:${relay.targetPort}` : (relay.exit || '旧版档案'); return `<div class="healthrow"><i class="${state === 'running' ? '' : 'off'}"></i><div><strong>${esc(relay.name)}</strong><br><small>${esc(listen)} → ${esc(target)}</small></div><small>${state === 'running' ? `↑${formatBytes(relay.bytesIn)} ↓${formatBytes(relay.bytesOut)}` : esc(relay.lastError || state)}</small></div>`; }).join('');
}
function populateRelayAgents() {
  const select = $('#relayAgent'); if (!select) return;
  select.innerHTML = '<option value="">本机面板</option>' + agents.filter(agent => agent.status !== 'disabled').map(agent => `<option value="${esc(agent.id)}">${esc(agent.name)} · ${agent.status === 'online' ? '在线' : '离线'}</option>`).join('');
}function renderAgents() {
  const online = agents.filter(agent => agent.status === 'online').length; $('#agentOnlineCount').textContent = online; $('#agentTotalCount').textContent = agents.length;
  $('#agentCards').innerHTML = agents.length ? agents.map(agent => { const status = agent.status || 'offline'; const system = [agent.hostname, agent.platform, agent.arch].filter(Boolean).join(' · ') || '尚未收到心跳'; const seen = agent.lastSeenAt ? new Date(agent.lastSeenAt).toLocaleString('zh-CN') : '从未连接'; const stateText = status === 'online' ? '在线' : status === 'disabled' ? '已停用' : '离线'; const relayCount = (agent.relayStates || []).filter(item => item.status === 'running').length; const inboundCount = (agent.inboundStates || []).filter(item => item.status === 'running').length; const updateText = agent.updatePending ? ' · 更新下发中' : ''; const xrayText = agent.xrayInstallPending ? 'Xray 安装下发中' : agent.xrayInstalling ? 'Xray 安装中' : agent.xrayAvailable ? agent.xrayVersion || 'Xray 可用' : 'Xray 未检测到'; const memory = agent.memoryTotal ? `${formatBytes(agent.memoryTotal - Number(agent.memoryFree || 0))} / ${formatBytes(agent.memoryTotal)}` : '-'; const ips = (agent.addresses || []).join(', ') || '-'; const collapsed = agentCardCollapsed.has(agent.id); return `<article class="agent-card ${collapsed ? 'collapsed' : ''}"><div class="agent-title"><b>◉</b><div><strong>${esc(agent.name)}</strong><small>${esc(agent.id)}</small></div></div><div class="agent-system"><strong>${esc(system)}</strong><small title="${esc(agent.xrayInstallError || '')}">${esc(xrayText)}${updateText}</small></div><div class="status ${esc(status)}">${stateText}<br><small>${esc(seen)}</small></div><div class="agent-summary-actions"><button class="btn" onclick="toggleAgentCard('${esc(agent.id)}')">${collapsed ? '展开详情' : '收起详情'}</button><button class="btn" onclick="configureAgentInbound('${esc(agent.id)}')">配置节点</button><button class="btn" onclick="showAgentDetails('${esc(agent.id)}')">完整详情</button></div><div class="agent-expanded"><div class="agent-quick"><div><small>公网 / 网卡地址</small><strong title="${esc(ips)}">${esc(ips)}</strong></div><div><small>CPU / 内存</small><strong>${esc(agent.cpus || '-')} 核 · ${esc(memory)}</strong></div><div><small>Xray Core</small><strong title="${esc(agent.xrayInstallError || '')}">${esc(xrayText)}</strong></div><div><small>运行版本</small><strong>Agent ${esc(agent.version || '-')} · Node ${esc(agent.nodeVersion || '-')}</strong></div><div><small>进程 / 启动</small><strong>PID ${esc(agent.processId || '-')} · ${esc(agent.agentStartedAt ? new Date(agent.agentStartedAt).toLocaleString('zh-CN') : '-')}</strong></div><div><small>已接管资源</small><strong>节点 ${inboundCount} · 中转 ${relayCount}</strong></div></div><div class="agent-actions"><button class="btn" onclick="requestAgentXrayInstall('${esc(agent.id)}')" ${agent.xrayInstallPending ? 'disabled' : ''}>安装 Xray</button><button class="btn" onclick="editAgentController('${esc(agent.id)}')">修改面板地址</button><button class="btn" onclick="showAgentBootstrap('${esc(agent.id)}')">部署 / 更新</button><button class="btn" onclick="requestAgentUpdate('${esc(agent.id)}')" ${agent.updatePending ? 'disabled' : ''}>一键更新</button><button class="btn" onclick="toggleAgent('${esc(agent.id)}')">${status === 'disabled' ? '启用' : '停用'}</button><button class="btn" onclick="rotateAgentToken('${esc(agent.id)}')">轮换令牌</button><button class="btn danger" onclick="deleteAgent('${esc(agent.id)}')">${zh.del}</button></div></div></article>`; }).join('') : '<article class="empty-state">尚未登记 Agent。添加机器后复制启动命令到目标 VPS。</article>';
}function showDeployment(deployment, title = '部署 Agent') {
  if (!deployment?.command) return;
  $('#agentBootstrapTitle').textContent = title; $('#agentCommand').textContent = deployment.command; $('#agentBootstrapModal').showModal();
}function applyInboundTemplate(reset = false) {
  const form = $('#inboundForm'); const protocol = $('#inboundProtocol').value; const template = inboundTemplates[protocol] || inboundTemplates['VLESS + Reality'];
  $('#templateName').textContent = template.name; $('#templateDesc').textContent = template.desc;
  form.querySelectorAll('[data-template]').forEach(label => {
    const visible = label.dataset.template.split(' ').includes(template.key); label.classList.toggle('template-hidden', !visible);
    const control = label.querySelector('input,select'); if (control) control.disabled = !visible;
  });
  Object.entries(template.defaults).forEach(([name, value]) => { const control = form.elements[name]; if (control && (reset || !control.value || control.dataset.auto === '1')) { control.value = value; control.dataset.auto = '1'; } });
}
function populateInboundAgents(selected = '') {
  const select = $('#inboundAgent'); if (!select) return;
  select.innerHTML = '<option value="">本机面板 Xray</option>' + agents.filter(agent => agent.status !== 'disabled').map(agent => `<option value="${esc(agent.id)}">${esc(agent.name)} · ${agent.xrayAvailable ? 'Xray 可用' : '缺少 Xray'}</option>`).join(''); select.value = selected;
}
function renderInbounds() {
  $('#inboundCards').innerHTML = inbounds.length ? inbounds.map(inbound => { const state = inbound.status || 'stopped'; const stateText = state === 'running' ? zh.run : state === 'starting' ? '下发中' : state === 'error' ? '异常' : state === 'offline' ? 'Agent 离线' : zh.stop; const executor = inbound.agentId ? `Agent · ${inbound.agentName || inbound.agentId}` : '本机 Xray'; return `<article class="node-card"><div class="inbound-title"><b>◈</b><div><strong>${esc(inbound.name)}</strong><small>${esc(inbound.template || inbound.protocol || inbound.protocolCode)} · ${esc(executor)}</small></div></div><div class="inbound-meta"><b>${zh.listen}</b>${esc(inbound.port)}</div><div class="inbound-meta"><b>${zh.server}</b>${esc(inbound.serverAddress || '-')}</div><div class="status ${esc(state)}">${stateText}<br><small title="${esc(inbound.lastError || '')}">${esc(inbound.lastError || `${zh.security}: ${inbound.security}`)}</small></div><div class="node-link wide"><b>${zh.link}</b><code>${esc(inbound.shareLink || '')}</code></div><div class="inbound-meta wide"><b>${zh.remark}</b>${esc(inbound.remark || zh.noRemark)}</div><details class="node-json wide"><summary>Xray JSON</summary><pre>${esc(JSON.stringify(inbound.xray || {}, null, 2))}</pre></details><div class="inbound-actions wide"><button class="btn" onclick="editInbound(${inbound.id})">编辑</button><button class="btn" onclick="showInboundQr(${inbound.id})">二维码</button><button class="btn" onclick="copyInbound(${inbound.id}, 'shareLink')">${zh.copyLink}</button><button class="btn" onclick="copyInbound(${inbound.id}, 'xray')">${zh.copyJson}</button><button class="btn" onclick="toggleInbound(${inbound.id})">${state === 'running' || state === 'starting' ? zh.pause : zh.enable}</button><button class="btn danger" onclick="deleteInbound(${inbound.id})">${zh.del}</button></div></article>`; }).join('') : `<article>${zh.emptyInbound}</article>`;
  const running = inbounds.filter(inbound => inbound.status === 'running').length; $('#inboundCount').innerHTML = `${running} <small>/ ${inbounds.length}</small>`;
}function populateUserInbounds() {
  const select = $('#userInbound');
  if (!select) return;
  select.innerHTML = '<option value="">仅创建用户档案</option>' + inbounds.filter(item => item.status === 'running').map(item => `<option value="${item.id}">${esc(item.name)} · ${esc(item.protocol)}</option>`).join('');
}
function renderUsers() {
  $('#userCards').innerHTML = users.length ? users.map(user => {
    const used = Number(user.usedGB || 0), limit = Number(user.limitGB || 0), percent = limit > 0 ? Math.min(100, Math.round(used / limit * 100)) : 0;
    return `<article><div class="user-main"><b>◎</b><div><strong>${esc(user.name)}</strong><small>${esc(user.email)}</small>${user.access?.[0] ? `<small class="access-label">已绑定：${esc(user.access[0].protocol)}</small>` : ''}</div></div><div class="quota"><span><i style="width:${percent}%"></i></span><small>${used.toFixed(1)} / ${limit} GB</small></div><div class="status ${esc(user.status)}">${user.status === 'running' ? zh.run : zh.stop}<br><small>${esc(user.expire || '长期有效')}</small></div><div class="inbound-actions">${user.access?.[0]?.link ? `<button class="btn" onclick="copyUserLink(${user.id})">节点链接</button>` : ''}<button class="btn" onclick="toggleUser(${user.id})">${user.status === 'running' ? zh.pause : zh.enable}</button><button class="btn danger" onclick="deleteUser(${user.id})">${zh.del}</button></div></article>`;
  }).join('') : `<article>${zh.emptyUser}</article>`;
  $('#userCount').textContent = users.filter(user => user.status === 'running').length;
}
function formatGB(value) { return Number(value || 0).toLocaleString('zh-CN', { maximumFractionDigits: 2 }); }
function renderTraffic() {
  if (!traffic) return;
  const summary = traffic.summary; $('#trafficTotal').innerHTML = `${formatGB(summary.totalGB)} <small>GB</small>`; $('#trafficRecorded').innerHTML = `${formatGB(summary.recordedGB)} <small>GB</small>`; $('#trafficActive').textContent = summary.activeUsers; $('#trafficRecords').textContent = summary.totalRecords;
  const overviewTraffic = $('#overviewTraffic'), overviewNote = $('#overviewTrafficNote'), overviewChart = $('#overviewChart');
  if (overviewTraffic) overviewTraffic.innerHTML = `${formatGB(summary.recordedGB)} <small>GB</small>`;
  if (overviewNote) overviewNote.textContent = summary.totalRecords ? `已记录 ${summary.totalRecords} 条流量` : '暂无流量记录';
  if (overviewChart) {
    const activeDays = traffic.daily.filter(item => Number(item.gb) > 0);
    overviewChart.innerHTML = activeDays.length ? activeDays.map(item => `<span>${esc(item.day)}：<b>${formatGB(item.gb)} GB</b></span>`).join('　') : '<p class="empty-state">暂无流量数据。</p>';
  }
  const maximum = Math.max(1, ...traffic.daily.map(item => item.gb));
  $('#trafficDays').innerHTML = traffic.daily.map(item => `<div><span title="${esc(item.day)}：${formatGB(item.gb)} GB"><i style="height:${Math.max(5, item.gb / maximum * 100)}%"></i></span><small>${esc(item.day.slice(5))}</small><b>${formatGB(item.gb)}</b></div>`).join('');
  $('#trafficInbounds').innerHTML = traffic.inbounds.length ? traffic.inbounds.map(item => `<div class="usage-row"><div><strong>${esc(item.name)}</strong><small>${esc(item.protocol)}</small></div><b>${formatGB(item.gb)} GB</b></div>`).join('') : '<p class="empty-state">暂无入站流量记录。</p>';
  $('#trafficUsers').innerHTML = traffic.users.length ? traffic.users.map(item => { const percent = item.limitGB ? Math.min(100, item.usedGB / item.limitGB * 100) : 0; return `<div class="traffic-user"><div><strong>${esc(item.name)}</strong><small>${esc(item.email)} · ${item.status === 'running' ? '可用' : '已暂停'}</small></div><div class="quota"><span><i style="width:${percent}%"></i></span><small>${formatGB(item.usedGB)} / ${formatGB(item.limitGB)} GB</small></div></div>`; }).join('') : '<p class="empty-state">暂无用户。</p>';
  $('#trafficLog').innerHTML = traffic.records.length ? traffic.records.map(item => `<div class="traffic-log"><div><strong>${esc(item.userName)}</strong><small>${esc(item.inboundName)} · ${item.direction === 'upload' ? '上传' : '下载'} · ${new Date(item.at).toLocaleString('zh-CN')}</small></div><b>${formatGB(item.gb)} GB</b></div>`).join('') : '<p class="empty-state">暂无记录。点击“记录流量”开始统计。</p>';
}
function populateTrafficOptions() {
  const userSelect = $('#trafficUser'), inboundSelect = $('#trafficInbound');
  userSelect.innerHTML = users.filter(item => item.status === 'running').map(item => `<option value="${item.id}">${esc(item.name)} · ${esc(item.email)}</option>`).join('') || '<option value="">没有可用用户</option>';
  inboundSelect.innerHTML = '<option value="">未指定入站</option>' + inbounds.filter(item => item.status === 'running').map(item => `<option value="${item.id}">${esc(item.name)} · ${esc(item.protocol)}</option>`).join('');
}function renderSystem() {
  if (!systemInfo) return;
  $('#adminName').textContent = systemInfo.admin.username;
  const tls = systemInfo.tls;
  $('#tlsDomain').value = tls.domain || ''; $('#tlsEmail').value = tls.email || ''; $('#certPath').value = tls.certPath || ''; $('#keyPath').value = tls.keyPath || '';
  $('#tlsSummary').textContent = tls.ready ? `证书已就绪：${tls.domain}（重启后启用 HTTPS）` : tls.domain ? `已保存 ${tls.domain} 的配置，尚未检测到可用证书文件。` : '尚未配置证书。';
  const status = $('#certStatus'); status.textContent = tls.ready ? '证书就绪' : systemInfo.certbotAvailable ? '可申请证书' : '需要 certbot'; status.className = `cert-status ${tls.ready ? 'ready' : ''}`;
  const runtime = systemInfo.runtime || {}; const coreText = runtime.running ? `Core 运行中（PID ${runtime.pid}）` : runtime.available ? 'Core 已检测到，尚未启动' : '未检测到 Xray Core';
  $('#runtimeSummary').textContent = coreText; $('#runtimeDetail').textContent = runtime.running ? `已监听 ${runtime.enabledInbounds} 个已启用入站` : (runtime.lastError || (runtime.available ? `版本：${runtime.version || '未知'}；已启用入站：${runtime.enabledInbounds}` : '安装 Xray Core 后可由面板生成配置并启动。'));
  $('#runtimeVersion').textContent = runtime.installedVersion || '未安装';
  const network = systemInfo.network || {}; $('#publicAddress').textContent = network.publicAddress || '未识别'; $('#publicAddressDetail').textContent = network.publicAddress ? `来源：${network.source} · ${network.checkedAt ? new Date(network.checkedAt).toLocaleString('zh-CN') : ''}` : (network.checking ? '正在检测 VPS 公网地址…' : (network.error || '可在此重新检测，或设置环境变量 PUBLIC_ADDRESS。')); $('#detectAddress').disabled = Boolean(network.checking);
  if (!$('#coreVersion').value && runtime.installedVersion) $('#coreVersion').placeholder = `当前 ${runtime.installedVersion}；留空安装最新`;
  $('#installCore').disabled = runtime.installing || runtime.running; $('#installCore').textContent = runtime.installing ? '正在安装…' : runtime.available ? '切换 / 更新 Core' : '一键安装 Core';
  $('#startRuntime').disabled = !runtime.available || runtime.running; $('#startRuntime').title = runtime.enabledInbounds ? '' : '当前没有启用的入站；仍可先启动 Core，新增入站后会自动重载。'; $('#stopRuntime').disabled = !runtime.running;
}
async function load() {
  try {
    const [relayData, inboundData, userData, agentData, config, trafficData] = await Promise.all([api('/api/relays'), api('/api/inbounds'), api('/api/users'), api('/api/agents'), api('/api/system'), api('/api/traffic')]);
    relays = relayData; inbounds = inboundData; users = userData; agents = agentData; systemInfo = config; traffic = trafficData; renderRelays(); renderInbounds(); renderUsers(); renderAgents(); renderTraffic(); renderSystem();
  } catch (error) {
    console.error(error); $('#cards').innerHTML = `<article>${zh.apiFailed}</article>`; $('#inboundCards').innerHTML = `<article>${zh.apiFailed}</article>`; $('#userCards').innerHTML = `<article>${zh.apiFailed}</article>`;
  }
}
async function patchStatus(type, id, status) { await api(`/api/${type}/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }); await load(); }
async function copyText(value) {
  const text = String(value || ''); if (!text) throw new Error('没有可复制的内容');
  if (navigator.clipboard && window.isSecureContext) { try { await navigator.clipboard.writeText(text); alert(zh.copied); return; } catch {} }
  const textarea = document.createElement('textarea'); textarea.value = text; textarea.setAttribute('readonly', ''); textarea.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0'; document.body.appendChild(textarea); textarea.select(); textarea.setSelectionRange(0, textarea.value.length);
  const copied = document.execCommand('copy'); textarea.remove(); if (!copied) throw new Error('浏览器拒绝复制权限'); alert(zh.copied);
}
window.editInbound = id => {
  const inbound = inbounds.find(item => item.id === id); if (!inbound) return;
  editingInboundId = id; const form = $('#inboundForm'); form.reset(); populateInboundAgents(inbound.agentId || '');
  $('#inboundProtocol').value = inbound.protocol; applyInboundTemplate(true);
  const stream = inbound.streamSettings || {}, reality = stream.realitySettings || {}, realityMeta = reality.settings || {}, client = inbound.settings?.clients?.[0] || {}, ws = stream.wsSettings || {}, grpc = stream.grpcSettings || {};
  const values = { name: inbound.name, port: inbound.port, serverAddress: inbound.serverAddress, sni: reality.serverNames?.[0] || stream.tlsSettings?.serverName || '', dest: reality.dest || '', fingerprint: realityMeta.fingerprint || 'chrome', flow: client.flow || 'xtls-rprx-vision', email: client.email || '', path: ws.path || '/vless', host: ws.headers?.Host || '', serviceName: grpc.serviceName || 'vless-grpc', method: inbound.settings?.method || '2022-blake3-aes-128-gcm', remark: inbound.remark || '' };
  Object.entries(values).forEach(([name, value]) => { if (form.elements[name]) form.elements[name].value = value; }); $('#inboundAgent').value = inbound.agentId || ''; $('#inboundProtocol').disabled = true;
  $('#inboundModalTitle').textContent = '编辑入站节点'; $('#inboundSubmit').textContent = '保存修改'; $('#inboundModal').showModal();
};window.showInboundQr = id => { const inbound = inbounds.find(item => item.id === id); if (!inbound) return; $('#qrTitle').textContent = `${inbound.name} · 节点二维码`; $('#qrImage').src = `/api/inbounds/${id}/qr?t=${Date.now()}`; $('#qrModal').showModal(); };window.copyInbound = async (id, field) => { const inbound = inbounds.find(item => item.id === id); if (!inbound) return; const value = field === 'xray' ? JSON.stringify(inbound.xray || {}, null, 2) : inbound.shareLink; try { await copyText(value || ''); } catch { prompt(field === 'xray' ? zh.copyJson : zh.copyLink, value || ''); } };
window.toggleAgentCard = id => { if (agentCardCollapsed.has(id)) agentCardCollapsed.delete(id); else agentCardCollapsed.add(id); localStorage.setItem('3xui-agent-collapsed', JSON.stringify([...agentCardCollapsed])); renderAgents(); };window.configureAgentInbound = id => { const agent = agents.find(item => item.id === id); if (!agent) return; editingInboundId = null; const form = $('#inboundForm'); form.reset(); $('#inboundProtocol').disabled = false; $('#inboundModalTitle').textContent = '生成入站节点'; $('#inboundSubmit').textContent = '生成节点'; populateInboundAgents(id); applyInboundTemplate(true); const address = $('#inboundForm').elements.serverAddress; if (address && !address.value) address.value = agent.addresses?.[0] || ''; $('#inboundModal').showModal(); };window.showAgentDetails = id => { const agent = agents.find(item => item.id === id); if (!agent) return; const seconds = Number(agent.uptimeSeconds || 0), uptime = seconds ? `${Math.floor(seconds / 86400)} 天 ${Math.floor(seconds % 86400 / 3600)} 小时 ${Math.floor(seconds % 3600 / 60)} 分` : '-'; const memory = agent.memoryTotal ? `${formatBytes(agent.memoryTotal - Number(agent.memoryFree || 0))} / ${formatBytes(agent.memoryTotal)}` : '-'; const rows = [['机器 ID', agent.id], ['控制地址', agent.controllerUrl], ['在线状态', agent.status], ['Xray Core', agent.xrayAvailable ? agent.xrayVersion || '可用' : '未检测到'], ['Xray 安装状态', agent.xrayInstallPending || agent.xrayInstalling ? '安装中' : agent.xrayInstallError || (agent.xrayInstalledAt ? `已安装：${new Date(agent.xrayInstalledAt).toLocaleString('zh-CN')}` : '-')], ['主机名', agent.hostname || '-'], ['系统', agent.platform || '-'], ['架构', agent.arch || '-'], ['网卡地址', (agent.addresses || []).join(', ') || '-'], ['CPU 逻辑核', agent.cpus || '-'], ['内存（已用 / 总量）', memory], ['系统运行时长', uptime], ['Agent PID', agent.processId || '-'], ['Agent 启动时间', agent.agentStartedAt ? new Date(agent.agentStartedAt).toLocaleString('zh-CN') : '-'], ['Node.js', agent.nodeVersion || '-'], ['Agent 版本', agent.version || '-'], ['首次登记', agent.createdAt ? new Date(agent.createdAt).toLocaleString('zh-CN') : '-'], ['最后心跳', agent.lastSeenAt ? new Date(agent.lastSeenAt).toLocaleString('zh-CN') : '-']]; const inboundRows = (agent.inboundStates || []).length ? agent.inboundStates.map(item => `<li><b>节点 #${esc(item.id)}</b> · ${esc(item.status)}${item.lastError ? `<small>${esc(item.lastError)}</small>` : ''}</li>`).join('') : '<li>尚未接管节点。</li>'; const relayRows = (agent.relayStates || []).length ? agent.relayStates.map(item => `<li><b>中转 #${esc(item.id)}</b> · ${esc(item.status)} · 连接 ${Number(item.connections || 0)} · ↑${formatBytes(item.bytesIn)} ↓${formatBytes(item.bytesOut)}${item.lastError ? `<small>${esc(item.lastError)}</small>` : ''}</li>`).join('') : '<li>尚未接管中转规则。</li>'; $('#agentDetailsTitle').textContent = `${agent.name} · Agent 详情`; $('#agentDetailsBody').innerHTML = `<div class="agent-detail-grid">${rows.map(([key, value]) => `<div><small>${esc(key)}</small><strong>${esc(value || '-')}</strong></div>`).join('')}</div><h3>已上报节点</h3><ul class="agent-relay-list">${inboundRows}</ul><h3>已上报中转</h3><ul class="agent-relay-list">${relayRows}</ul>`; $('#agentDetailsModal').showModal(); };window.showAgentBootstrap = async id => { try { const deployment = await api(`/api/agents/${encodeURIComponent(id)}/bootstrap`); showDeployment(deployment, '部署 Agent'); } catch (error) { alert(error.message); } };
window.editAgentController = async id => {
  const agent = agents.find(item => item.id === id); if (!agent) return;
  const controllerUrl = prompt('请输入 Agent 可访问的面板地址（同机可使用 http://127.0.0.1:3000）：', agent.controllerUrl || location.origin);
  if (controllerUrl === null) return;
  try {
    const response = await api(`/api/agents/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ controllerUrl }) });
    showDeployment(response.deployment, '地址已更新：重新部署 Agent');
    await load();
  } catch (error) { alert(error.message); }
};window.toggleAgent = async id => { const agent = agents.find(item => item.id === id); if (!agent) return; try { await api(`/api/agents/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ enabled: agent.status === 'disabled' }) }); await load(); } catch (error) { alert(error.message); } };
window.requestAgentXrayInstall = async id => { const agent = agents.find(item => item.id === id); if (!agent || agent.xrayInstallPending) return; if (!confirm(`向 ${agent.name} 下发 Xray Core 自动安装？将下载官方 release、校验 SHA-256 并安装到该 Agent 私有目录。`)) return; try { const response = await api(`/api/agents/${encodeURIComponent(id)}/xray/install`, { method: 'POST', body: '{}' }); alert(response.message || 'Xray 安装任务已下发。'); await load(); } catch (error) { alert(error.message); } };window.requestAgentUpdate = async id => { const agent = agents.find(item => item.id === id); if (!agent || agent.updatePending) return; if (!confirm(`向 ${agent.name} 下发一键更新？Agent 会下载当前脚本并由 systemd 重启。`)) return; try { const response = await api(`/api/agents/${encodeURIComponent(id)}/update`, { method: 'POST', body: '{}' }); alert(response.message || '更新请求已下发。'); await load(); } catch (error) { alert(error.message); } };window.rotateAgentToken = async id => { if (!confirm('轮换令牌会使当前 Agent 在下一次心跳停止所有中转。需要重新部署后才能恢复，确定继续吗？')) return; try { const response = await api(`/api/agents/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ rotateToken: true }) }); showDeployment(response.deployment, '令牌已轮换：重新部署 Agent'); await load(); } catch (error) { alert(error.message); } };window.deleteAgent = async id => { if (!confirm('删除该 Agent 后，它的令牌将立即失效。确定继续吗？')) return; try { await api(`/api/agents/${encodeURIComponent(id)}`, { method: 'DELETE' }); await load(); } catch (error) { alert(error.message); } };window.toggleRelay = async id => { const item = relays.find(value => value.id === id); if (!item) return; try { await patchStatus('relays', id, item.status === 'running' ? 'stopped' : 'running'); } catch (error) { alert(error.message); } };
window.deleteRelay = async id => { if (confirm(zh.confirmRelay)) try { await api(`/api/relays/${id}`, { method: 'DELETE' }); await load(); } catch (error) { alert(error.message); } };
window.toggleInbound = async id => { const item = inbounds.find(value => value.id === id); if (!item) return; try { await patchStatus('inbounds', id, item.status === 'running' ? 'stopped' : 'running'); } catch (error) { alert(error.message); } };
window.deleteInbound = async id => { if (confirm(zh.confirmInbound)) try { await api(`/api/inbounds/${id}`, { method: 'DELETE' }); await load(); } catch (error) { alert(error.message); } };
window.copyUserLink = async id => { const user = users.find(item => item.id === id); const link = user?.access?.[0]?.link; if (!link) return; try { await copyText(link); } catch { prompt('节点链接', link); } };
window.toggleUser = async id => { const item = users.find(value => value.id === id); if (!item) return; try { await patchStatus('users', id, item.status === 'running' ? 'stopped' : 'running'); } catch (error) { alert(error.message); } };
window.deleteUser = async id => { if (confirm(zh.confirmUser)) try { await api(`/api/users/${id}`, { method: 'DELETE' }); await load(); } catch (error) { alert(error.message); } };
function activatePage(id) { document.querySelectorAll('.page').forEach(page => page.classList.toggle('active', page.id === id)); document.querySelectorAll('.nav').forEach(nav => nav.classList.toggle('active', nav.dataset.page === id)); $('#crumb').innerHTML = `控制台 / <strong>${pageNames[id] || id}</strong>`; $('.sidebar').classList.remove('open'); }

document.querySelectorAll('.nav,[data-go]').forEach(link => link.onclick = event => { const id = link.dataset.page || link.dataset.go; if (!id) return; event.preventDefault(); activatePage(id); });
$('#search').oninput = renderRelays;
document.querySelectorAll('.filter').forEach(button => button.onclick = () => { filter = button.dataset.filter; document.querySelectorAll('.filter').forEach(item => item.classList.toggle('active', item === button)); renderRelays(); });
$('#newRelay').onclick = () => { populateRelayAgents(); $('#modal').showModal(); };
$('#newAgent').onclick = () => { $('#agentControllerUrl').value = location.origin; $('#agentModal').showModal(); };$('#newInbound').onclick = () => { editingInboundId = null; const form = $('#inboundForm'); form.reset(); $('#inboundProtocol').disabled = false; $('#inboundModalTitle').textContent = '生成入站节点'; $('#inboundSubmit').textContent = '生成节点'; populateInboundAgents(); applyInboundTemplate(true); const address = form.elements.serverAddress; if (address && !address.value && systemInfo?.network?.publicAddress) address.value = systemInfo.network.publicAddress; $('#inboundModal').showModal(); };
$('#newUser').onclick = () => { populateUserInbounds(); $('#userModal').showModal(); };
$('#newTraffic').onclick = () => { populateTrafficOptions(); $('#trafficModal').showModal(); };
$('#changePassword').onclick = () => $('#passwordModal').showModal();
$('#openSystem').onclick = () => activatePage('system');
$('#inboundProtocol').onchange = () => applyInboundTemplate(true);
$('#inboundForm').addEventListener('input', event => { if (event.target.name) event.target.dataset.auto = '0'; });
applyInboundTemplate(true);
document.querySelectorAll('[data-close]').forEach(button => button.onclick = () => button.closest('dialog').close());
$('#form').onsubmit = async event => { event.preventDefault(); try { await api('/api/relays', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.target))) }); event.target.reset(); $('#modal').close(); await load(); } catch (error) { alert(error.message); } };
$('#agentForm').onsubmit = async event => { event.preventDefault(); try { const response = await api('/api/agents', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.target))) }); event.target.reset(); $('#agentModal').close(); showDeployment(response.deployment, `部署 ${response.agent.name}`); await load(); } catch (error) { alert(error.message); } };
$('#copyAgentCommand').onclick = async () => { try { await copyText($('#agentCommand').textContent); } catch { prompt('启动命令', $('#agentCommand').textContent); } };$('#inboundForm').onsubmit = async event => { event.preventDefault(); try { const target = editingInboundId ? '/api/inbounds/' + editingInboundId : '/api/inbounds'; await api(target, { method: editingInboundId ? 'PATCH' : 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.target))) }); editingInboundId = null; event.target.reset(); $('#inboundProtocol').disabled = false; $('#inboundModal').close(); await load(); } catch (error) { alert(error.message); } };
$('#userForm').onsubmit = async event => { event.preventDefault(); try { await api('/api/users', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.target))) }); event.target.reset(); $('#userModal').close(); await load(); } catch (error) { alert(error.message); } };
$('#trafficForm').onsubmit = async event => { event.preventDefault(); try { const response = await api('/api/traffic/record', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.target))) }); event.target.reset(); $('#trafficModal').close(); await load(); if (response.reachedLimit) alert('该用户已达到流量配额，系统已自动暂停其访问。'); } catch (error) { alert(error.message); } };$('#passwordForm').onsubmit = async event => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); if (data.newPassword !== data.confirmPassword) return alert('两次新密码不一致'); try { await api('/api/system/password', { method: 'POST', body: JSON.stringify(data) }); event.target.reset(); $('#passwordModal').close(); showLogin('密码已更新，请使用新密码重新登录。'); } catch (error) { alert(error.message); } };
$('#tlsForm').onsubmit = async event => { event.preventDefault(); try { const data = Object.fromEntries(new FormData(event.target)); const response = await api('/api/system/tls', { method: 'POST', body: JSON.stringify(data) }); systemInfo.tls = response.tls; renderSystem(); alert('证书配置已保存。'); } catch (error) { alert(error.message); } };
$('#requestCert').onclick = async () => { const data = Object.fromEntries(new FormData($('#tlsForm'))); try { const response = await api('/api/system/tls/request', { method: 'POST', body: JSON.stringify(data) }); systemInfo.tls = response.tls; renderSystem(); alert(response.message); } catch (error) { alert(error.message); } };
$('#applyCert').onclick = async () => { try { const response = await api('/api/system/tls/apply', { method: 'POST' }); alert(response.message); await load(); } catch (error) { alert(error.message); } };
$('#installCore').onclick = async () => { try { const version = $('#coreVersion').value.trim(); $('#installCore').disabled = true; $('#installCore').textContent = '正在下载并校验…'; const response = await api('/api/runtime/install', { method: 'POST', body: JSON.stringify({ version }) }); systemInfo.runtime = response.info; systemInfo.network = response.network || systemInfo.network; $('#coreVersion').value = ''; renderSystem(); alert(`Xray Core ${response.version || ''} 已安装，可点击“启动 Core”。`); } catch (error) { alert(error.message); await load(); } };$('#detectAddress').onclick = async () => { try { $('#detectAddress').disabled = true; $('#publicAddressDetail').textContent = '正在检测 VPS 公网地址…'; systemInfo.network = await api('/api/system/network/detect', { method: 'POST' }); renderSystem(); } catch (error) { alert(error.message); await load(); } };$('#startRuntime').onclick = async () => { try { const runtime = await api('/api/runtime/start', { method: 'POST' }); systemInfo.runtime = runtime; renderSystem(); await load(); } catch (error) { alert(error.message); } };
$('#stopRuntime').onclick = async () => { try { const runtime = await api('/api/runtime/stop', { method: 'POST' }); systemInfo.runtime = runtime; renderSystem(); } catch (error) { alert(error.message); } };
$('#downloadConfig').onclick = async () => { try { const config = await api('/api/runtime/config'); const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'xray-config.json'; link.click(); URL.revokeObjectURL(url); } catch (error) { alert(error.message); } };$('#loginForm').onsubmit = async event => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.target)); try { const response = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(data) }); hideLogin(); $('#loginForm').reset(); if (response.mustChangePassword) setTimeout(() => $('#passwordModal').showModal(), 250); await load(); } catch (error) { $('#loginNote').textContent = error.message; } };
$('#logout').onclick = async () => { try { await api('/api/auth/logout', { method: 'POST' }); } finally { showLogin('已安全退出。'); } };
$('#theme').onclick = () => document.body.classList.toggle('dark');
$('#menu').onclick = () => $('.sidebar').classList.toggle('open');
(async () => { try { const session = await api('/api/auth/me'); if (session.authenticated) { hideLogin(); await load(); if (session.mustChangePassword) setTimeout(() => $('#passwordModal').showModal(), 250); } else showLogin(); } catch { showLogin('无法连接面板服务，请确认已运行 node server.js。'); } })();







